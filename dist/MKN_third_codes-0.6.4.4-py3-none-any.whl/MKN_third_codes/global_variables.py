regular_int = r'-?\d+'
regular_float = r'-?\d+(?:[\.\,]\d+)?'